---
name: App request
about: Suggest an app for this project
title: App Request
labels: ''
assignees: ''

---

**Which app do you want to be added?**

**What is the website link?**

**What is the icon that should be used?**
